package com.trainoptimizer.service;

import com.trainoptimizer.model.RailwayNetwork;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class NetworkBuilderTest {

    @Test
    void BuildRomanianNetwork_HasExpectedStations() {
        RailwayNetwork network = NetworkBuilder.buildRomanianNetwork();

        assertThat(network.findStation("Bucharest")).isPresent();
        assertThat(network.findStation("Cluj-Napoca")).isPresent();
        assertThat(network.findStation("Timisoara")).isPresent();
        assertThat(network.findStation("Iasi")).isPresent();
        assertThat(network.findStation("Brasov")).isPresent();
        assertThat(network.findStation("Sibiu")).isPresent();
    }

    @Test
    void BuildRomanianNetwork_HasServices() {
        RailwayNetwork network = NetworkBuilder.buildRomanianNetwork();

        assertThat(network.getServices()).isNotEmpty();
    }

    @Test
    void BuildRomanianNetwork_AllServicesHaveAtLeastTwoStops() {
        RailwayNetwork network = NetworkBuilder.buildRomanianNetwork();

        network.getServices().forEach(service ->
                assertThat(service.getStops()).hasSizeGreaterThanOrEqualTo(2));
    }

    @Test
    void BuildRomanianNetwork_FirstStopHasNullArrival() {
        
        NetworkBuilder.buildRomanianNetwork().getServices().forEach(service -> {
            assertThat(service.getStops().get(0).getArrival())
                    .as("First stop of %s should have null arrival", service.getName())
                    .isNull();
        });
    }

    @Test
    void BuildRomanianNetwork_LastStopHasNullDeparture() {
        
        NetworkBuilder.buildRomanianNetwork().getServices().forEach(service -> {
            var stops = service.getStops();
            assertThat(stops.get(stops.size() - 1).getDeparture())
                    .as("Last stop of %s should have null departure", service.getName())
                    .isNull();
        });
    }
}

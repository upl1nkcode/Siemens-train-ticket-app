package com.trainoptimizer.algorithm;

import com.trainoptimizer.model.*;
import com.trainoptimizer.service.NetworkBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;

class TimeExpandedDijkstraTest {

    private TimeExpandedDijkstra planner;

    @BeforeEach
    void setUp() {
        planner = new TimeExpandedDijkstra(NetworkBuilder.buildRomanianNetwork());
    }

    

    @Test
    void FindOptimalJourney_DirectRoute_ReturnsZeroChangeovers() {
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Brasov", LocalTime.of(7, 0));

        assertThat(result).isPresent();
        assertThat(result.get().getChangeovers()).isEqualTo(0);
        assertThat(result.get().getLegs()).hasSize(1);
        assertThat(result.get().getLegs().get(0).getServiceName()).isEqualTo("IR 1581");
    }

    @Test
    void FindOptimalJourney_RequiresChangeover_ReturnsCorrectLegs() {
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Cluj-Napoca", LocalTime.of(6, 0));

        assertThat(result).isPresent();
        assertThat(result.get().getChangeovers()).isGreaterThanOrEqualTo(1);
        assertThat(result.get().getLegs().size()).isGreaterThanOrEqualTo(2);
    }

    @Test
    void FindOptimalJourney_DirectJourneyThroughIntermediateStop_StaysOnSameTrain() {
        
        Optional<Journey> result = planner.findOptimalJourney("Timisoara", "Iasi", LocalTime.of(8, 0));

        assertThat(result).isPresent();
        assertThat(result.get().getChangeovers()).isEqualTo(0);
        assertThat(result.get().getLegs().get(0).getServiceName()).isEqualTo("IR 2231");
    }

    @Test
    void FindOptimalJourney_PicksEarliestArrival_NotJustFirstDeparture() {
        
        
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Iasi", LocalTime.of(6, 0));

        assertThat(result).isPresent();
        assertThat(result.get().getLegs().get(0).getServiceName()).isEqualTo("IR 1990");
        assertThat(result.get().getArrivalTime()).isEqualTo(LocalTime.of(13, 15));
    }

    @Test
    void FindOptimalJourney_DepartureTimeConstraint_SkipsTrainsBeforeCutoff() {
        
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Brasov", LocalTime.of(9, 0));

        assertThat(result).isPresent();
        assertThat(result.get().getLegs().get(0).getDepartureTime())
                .isAfterOrEqualTo(LocalTime.of(9, 0));
    }

    @Test
    void FindOptimalJourney_ArrivalTimeIsAfterDeparture() {
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Brasov", LocalTime.of(7, 0));

        assertThat(result).isPresent();
        Journey j = result.get();
        assertThat(j.getArrivalTime()).isAfter(j.getDepartureTime());
    }

    @Test
    void FindOptimalJourney_TotalDurationIsPositive() {
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Timisoara", LocalTime.of(6, 0));

        assertThat(result).isPresent();
        assertThat(result.get().getTotalDuration().toMinutes()).isPositive();
    }

    

    @Test
    void FindOptimalJourney_NoTrainsAfterRequestedTime_ReturnsEmpty() {
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Brasov", LocalTime.of(23, 0));

        assertThat(result).isEmpty();
    }

    @Test
    void FindOptimalJourney_UnreachableStation_ReturnsEmpty() {
        
        RailwayNetwork isolated = new RailwayNetwork();
        isolated.addStation("Alpha");
        isolated.addStation("Beta");
        
        TimeExpandedDijkstra isolatedPlanner = new TimeExpandedDijkstra(isolated);

        Optional<Journey> result = isolatedPlanner.findOptimalJourney("Alpha", "Beta", LocalTime.of(8, 0));

        assertThat(result).isEmpty();
    }

    @Test
    void FindOptimalJourney_SameOriginAndDestination_ThrowsIllegalArgument() {
        assertThatThrownBy(() ->
                planner.findOptimalJourney("Bucharest", "Bucharest", LocalTime.of(8, 0)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("same station");
    }

    @Test
    void FindOptimalJourney_UnknownOrigin_ThrowsIllegalArgument() {
        assertThatThrownBy(() ->
                planner.findOptimalJourney("Atlantis", "Brasov", LocalTime.of(8, 0)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Unknown station");
    }

    @Test
    void FindOptimalJourney_UnknownDestination_ThrowsIllegalArgument() {
        assertThatThrownBy(() ->
                planner.findOptimalJourney("Bucharest", "Mordor", LocalTime.of(8, 0)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Unknown station");
    }

    @Test
    void FindOptimalJourney_NullNetwork_ThrowsNullPointer() {
        assertThatThrownBy(() -> new TimeExpandedDijkstra(null))
                .isInstanceOf(NullPointerException.class);
    }

    

    @Test
    void Journey_SingleLeg_HasZeroChangeovers() {
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Brasov", LocalTime.of(7, 0));

        assertThat(result).isPresent();
        assertThat(result.get().getChangeovers()).isZero();
    }

    @Test
    void Journey_MultiLeg_LegsAreChronologicallyConsistent() {
        Optional<Journey> result = planner.findOptimalJourney("Bucharest", "Cluj-Napoca", LocalTime.of(6, 0));

        assertThat(result).isPresent();
        java.util.List<Journey.Leg> legs = result.get().getLegs();
        for (int i = 0; i < legs.size() - 1; i++) {
            
            assertThat(legs.get(i).getArrivalTime())
                    .isBeforeOrEqualTo(legs.get(i + 1).getDepartureTime());
        }
    }
}

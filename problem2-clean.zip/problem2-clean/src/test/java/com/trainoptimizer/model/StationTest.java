package com.trainoptimizer.model;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

class StationTest {

    @Test
    void Equality_CaseInsensitive() {
        Station a = new Station("Cluj-Napoca");
        Station b = new Station("cluj-napoca");

        assertThat(a).isEqualTo(b);
        assertThat(a.hashCode()).isEqualTo(b.hashCode());
    }

    @Test
    void Equality_DifferentNames_NotEqual() {
        assertThat(new Station("Bucharest")).isNotEqualTo(new Station("Brasov"));
    }

    @Test
    void NullName_ThrowsNullPointer() {
        assertThatThrownBy(() -> new Station(null))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    void ToString_ReturnsName() {
        assertThat(new Station("Sibiu").toString()).isEqualTo("Sibiu");
    }
}

package com.trainoptimizer.model;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalTime;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

class JourneyTest {

    private static Station station(String name) {
        return new Station(name);
    }

    private static Journey.Leg leg(String service, String from, String to,
                                   LocalTime dep, LocalTime arr) {
        return new Journey.Leg(service, station(from), station(to), dep, arr);
    }

    @Test
    void SingleLeg_DepartureAndArrivalCorrect() {
        Journey journey = new Journey(List.of(
                leg("IR 1581", "Bucharest", "Brasov", LocalTime.of(8, 30), LocalTime.of(11, 0))
        ));

        assertThat(journey.getDepartureTime()).isEqualTo(LocalTime.of(8, 30));
        assertThat(journey.getArrivalTime()).isEqualTo(LocalTime.of(11, 0));
    }

    @Test
    void SingleLeg_TotalDuration_Is150Minutes() {
        Journey journey = new Journey(List.of(
                leg("IR 1581", "Bucharest", "Brasov", LocalTime.of(8, 30), LocalTime.of(11, 0))
        ));

        assertThat(journey.getTotalDuration()).isEqualTo(Duration.ofMinutes(150));
    }

    @Test
    void SingleLeg_Changeovers_IsZero() {
        Journey journey = new Journey(List.of(
                leg("IR 1581", "Bucharest", "Brasov", LocalTime.of(8, 30), LocalTime.of(11, 0))
        ));

        assertThat(journey.getChangeovers()).isZero();
    }

    @Test
    void MultiLeg_Changeovers_IsLegsMinusOne() {
        Journey journey = new Journey(List.of(
                leg("IR 1581", "Bucharest", "Brasov", LocalTime.of(8, 30), LocalTime.of(11, 0)),
                leg("IR 1732", "Brasov", "Cluj-Napoca", LocalTime.of(11, 30), LocalTime.of(16, 30))
        ));

        assertThat(journey.getChangeovers()).isEqualTo(1);
        assertThat(journey.getLegs()).hasSize(2);
    }

    @Test
    void MultiLeg_TotalDurationIncludesWaitingTime() {
        
        Journey journey = new Journey(List.of(
                leg("IR 1581", "Bucharest", "Brasov", LocalTime.of(8, 30), LocalTime.of(11, 0)),
                leg("IR 1732", "Brasov", "Cluj-Napoca", LocalTime.of(11, 30), LocalTime.of(16, 30))
        ));

        assertThat(journey.getTotalDuration()).isEqualTo(Duration.ofMinutes(480));
    }

    @Test
    void Leg_Duration_CalculatedCorrectly() {
        Journey.Leg leg = leg("IR 1581", "Bucharest", "Brasov",
                LocalTime.of(8, 30), LocalTime.of(11, 0));

        assertThat(leg.getDuration()).isEqualTo(Duration.ofMinutes(150));
    }

    @Test
    void PrettyPrint_ContainsKeyInfo() {
        Journey journey = new Journey(List.of(
                leg("IR 1581", "Bucharest", "Brasov", LocalTime.of(8, 30), LocalTime.of(11, 0))
        ));

        String output = journey.prettyPrint();
        assertThat(output)
                .contains("Bucharest")
                .contains("Brasov")
                .contains("IR 1581")
                .contains("08:30")
                .contains("11:00");
    }
}

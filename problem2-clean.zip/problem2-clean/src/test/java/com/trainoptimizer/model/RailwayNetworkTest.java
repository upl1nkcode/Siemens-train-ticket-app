package com.trainoptimizer.model;

import org.junit.jupiter.api.Test;

import java.time.LocalTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;

class RailwayNetworkTest {

    @Test
    void AddStation_CanBeFoundByName() {
        RailwayNetwork network = new RailwayNetwork();
        network.addStation("Bucharest");

        assertThat(network.findStation("Bucharest")).isPresent();
    }

    @Test
    void FindStation_CaseInsensitive() {
        RailwayNetwork network = new RailwayNetwork();
        network.addStation("Cluj-Napoca");

        assertThat(network.findStation("cluj-napoca")).isPresent();
        assertThat(network.findStation("CLUJ-NAPOCA")).isPresent();
    }

    @Test
    void FindStation_Missing_ReturnsEmpty() {
        RailwayNetwork network = new RailwayNetwork();

        assertThat(network.findStation("Atlantis")).isEmpty();
    }

    @Test
    void AddStation_Duplicate_ReturnsSameInstance() {
        RailwayNetwork network = new RailwayNetwork();
        Station first = network.addStation("Bucharest");
        Station second = network.addStation("Bucharest");

        assertThat(first).isSameAs(second);
    }

    @Test
    void AddService_IncreasesServiceCount() {
        RailwayNetwork network = new RailwayNetwork();
        Station a = network.addStation("A");
        Station b = network.addStation("B");

        TrainService service = new TrainService("TEST")
                .addStop(a, null, LocalTime.of(8, 0))
                .addStop(b, LocalTime.of(10, 0), null);

        network.addService(service);

        assertThat(network.getServices()).hasSize(1);
    }

    @Test
    void AddService_Null_ThrowsNullPointer() {
        RailwayNetwork network = new RailwayNetwork();

        assertThatThrownBy(() -> network.addService(null))
                .isInstanceOf(NullPointerException.class);
    }
}

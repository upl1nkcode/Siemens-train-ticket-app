package com.trainoptimizer.service;

import com.trainoptimizer.model.*;

import java.time.LocalTime;


public class NetworkBuilder {

    private NetworkBuilder() {} 

    public static RailwayNetwork buildRomanianNetwork() {
        RailwayNetwork network = new RailwayNetwork();

        
        Station bucharest  = network.addStation("Bucharest");
        Station brasov     = network.addStation("Brasov");
        Station clujNapoca = network.addStation("Cluj-Napoca");
        Station timisoara  = network.addStation("Timisoara");
        Station sibiu      = network.addStation("Sibiu");
        Station iasi       = network.addStation("Iasi");
        Station craiova    = network.addStation("Craiova");
        Station oradea     = network.addStation("Oradea");

        

        
        network.addService(new TrainService("IR 1581")
                .addStop(bucharest, null, LocalTime.of(8, 30))
                .addStop(brasov, LocalTime.of(11, 0), null));

        
        network.addService(new TrainService("IR 1583")
                .addStop(bucharest, null, LocalTime.of(14, 0))
                .addStop(brasov, LocalTime.of(16, 30), null));

        
        network.addService(new TrainService("IR 1732")
                .addStop(brasov, null, LocalTime.of(11, 30))
                .addStop(sibiu, LocalTime.of(13, 30), LocalTime.of(13, 45))
                .addStop(clujNapoca, LocalTime.of(16, 30), null));

        
        network.addService(new TrainService("IR 1990")
                .addStop(bucharest, null, LocalTime.of(6, 45))
                .addStop(iasi, LocalTime.of(13, 15), null));

        
        network.addService(new TrainService("IR 1992")
                .addStop(bucharest, null, LocalTime.of(13, 30))
                .addStop(iasi, LocalTime.of(20, 0), null));

        
        network.addService(new TrainService("IR 2231")
                .addStop(timisoara, null, LocalTime.of(9, 15))
                .addStop(clujNapoca, LocalTime.of(13, 30), LocalTime.of(13, 45))
                .addStop(iasi, LocalTime.of(20, 30), null));

        
        network.addService(new TrainService("IR 2244")
                .addStop(bucharest, null, LocalTime.of(7, 0))
                .addStop(sibiu, LocalTime.of(11, 0), LocalTime.of(11, 15))
                .addStop(timisoara, LocalTime.of(14, 30), null));

        
        network.addService(new TrainService("IR 1680")
                .addStop(clujNapoca, null, LocalTime.of(17, 0))
                .addStop(oradea, LocalTime.of(20, 0), null));

        
        network.addService(new TrainService("IR 1695")
                .addStop(oradea, null, LocalTime.of(8, 0))
                .addStop(timisoara, LocalTime.of(11, 30), null));

        
        network.addService(new TrainService("IR 1750")
                .addStop(bucharest, null, LocalTime.of(9, 0))
                .addStop(craiova, LocalTime.of(12, 0), null));

        
        network.addService(new TrainService("IR 1755")
                .addStop(craiova, null, LocalTime.of(13, 0))
                .addStop(timisoara, LocalTime.of(17, 0), null));

        return network;
    }
}

package com.trainoptimizer.model;

import java.time.LocalTime;


public class ScheduledStop {

    private final Station station;
    private final LocalTime arrival;   
    private final LocalTime departure; 

    public ScheduledStop(Station station, LocalTime arrival, LocalTime departure) {
        this.station = station;
        this.arrival = arrival;
        this.departure = departure;
    }

    public Station getStation() { return station; }
    public LocalTime getArrival() { return arrival; }
    public LocalTime getDeparture() { return departure; }

    @Override
    public String toString() {
        return station.getName() + " [arr=" + arrival + ", dep=" + departure + "]";
    }
}

package com.trainoptimizer.model;

import java.util.*;


public class RailwayNetwork {

    private final Map<String, Station> stations = new LinkedHashMap<>();
    private final List<TrainService> services = new ArrayList<>();

    public Station addStation(String name) {
        return stations.computeIfAbsent(name.toLowerCase(), k -> new Station(name));
    }

    public Optional<Station> findStation(String name) {
        return Optional.ofNullable(stations.get(name.toLowerCase()));
    }

    public void addService(TrainService service) {
        services.add(Objects.requireNonNull(service));
    }

    public Collection<Station> getStations() {
        return Collections.unmodifiableCollection(stations.values());
    }

    public List<TrainService> getServices() {
        return Collections.unmodifiableList(services);
    }
}

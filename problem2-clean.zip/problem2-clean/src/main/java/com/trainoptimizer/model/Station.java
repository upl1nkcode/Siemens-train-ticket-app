package com.trainoptimizer.model;

import java.util.Objects;


public class Station {

    private final String name;

    public Station(String name) {
        this.name = Objects.requireNonNull(name, "Station name cannot be null");
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Station)) return false;
        return name.equalsIgnoreCase(((Station) o).name);
    }

    @Override
    public int hashCode() {
        return name.toLowerCase().hashCode();
    }

    @Override
    public String toString() {
        return name;
    }
}

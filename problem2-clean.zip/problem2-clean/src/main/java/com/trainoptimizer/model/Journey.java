package com.trainoptimizer.model;

import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Journey {

    private final List<Leg> legs;

    public Journey(List<Leg> legs) {
        this.legs = new ArrayList<>(legs);
    }

    public List<Leg> getLegs() {
        return Collections.unmodifiableList(legs);
    }

    public LocalTime getDepartureTime() {
        return legs.get(0).getDepartureTime();
    }

    public LocalTime getArrivalTime() {
        return legs.get(legs.size() - 1).getArrivalTime();
    }

    public Duration getTotalDuration() {
        long minutes = minutesBetween(getDepartureTime(), getArrivalTime());
        return Duration.ofMinutes(minutes);
    }

    public int getChangeovers() {
        return legs.size() - 1;
    }

    public String prettyPrint() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("  [OK] Journey found: %s -> %s%n",
                legs.get(0).getFromStation().getName(),
                legs.get(legs.size() - 1).getToStation().getName()));
        sb.append(String.format("    Total duration: %s | Changeovers: %d%n",
                formatDuration(getTotalDuration()), getChangeovers()));
        sb.append(String.format("    Depart: %s | Arrive: %s%n%n", getDepartureTime(), getArrivalTime()));

        for (int i = 0; i < legs.size(); i++) {
            Leg leg = legs.get(i);
            sb.append(String.format("    Leg %d: [%s] %s (%s) -> %s (%s)  - %s%n",
                    i + 1,
                    leg.getServiceName(),
                    leg.getFromStation().getName(), leg.getDepartureTime(),
                    leg.getToStation().getName(), leg.getArrivalTime(),
                    formatDuration(leg.getDuration())));


            if (i < legs.size() - 1) {
                Leg nextLeg = legs.get(i + 1);
                long waitMinutes = minutesBetween(leg.getArrivalTime(), nextLeg.getDepartureTime());
                sb.append(String.format("           -> Changeover at %s - wait %s%n",
                        leg.getToStation().getName(), formatDuration(Duration.ofMinutes(waitMinutes))));
            }
        }
        sb.append("\n");
        return sb.toString();
    }

    private static long minutesBetween(LocalTime from, LocalTime to) {
        long minutes = Duration.between(from, to).toMinutes();
        if (minutes < 0) minutes += 24 * 60; 
        return minutes;
    }

    private static String formatDuration(Duration d) {
        long hours = d.toHours();
        long minutes = d.toMinutes() % 60;
        if (hours > 0) return String.format("%dh %02dmin", hours, minutes);
        return String.format("%dmin", minutes);
    }

    
    public static class Leg {
        private final String serviceName;
        private final Station fromStation;
        private final Station toStation;
        private final LocalTime departureTime;
        private final LocalTime arrivalTime;

        public Leg(String serviceName, Station from, Station to,
                   LocalTime departure, LocalTime arrival) {
            this.serviceName = serviceName;
            this.fromStation = from;
            this.toStation = to;
            this.departureTime = departure;
            this.arrivalTime = arrival;
        }

        public String getServiceName() { return serviceName; }
        public Station getFromStation() { return fromStation; }
        public Station getToStation() { return toStation; }
        public LocalTime getDepartureTime() { return departureTime; }
        public LocalTime getArrivalTime() { return arrivalTime; }

        public Duration getDuration() {
            long minutes = minutesBetween(departureTime, arrivalTime);
            return Duration.ofMinutes(minutes);
        }
    }
}

package com.trainoptimizer.model;

import java.time.LocalTime;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;


public class TrainService {

    private final String name;
    private final List<ScheduledStop> stops;

    public TrainService(String name) {
        this.name = Objects.requireNonNull(name);
        this.stops = new ArrayList<>();
    }

    
    public TrainService addStop(Station station, LocalTime arrival, LocalTime departure) {
        stops.add(new ScheduledStop(station, arrival, departure));
        return this;
    }

    public String getName() {
        return name;
    }

    public List<ScheduledStop> getStops() {
        return Collections.unmodifiableList(stops);
    }

    public Station getOrigin() {
        return stops.get(0).getStation();
    }

    public Station getTerminus() {
        return stops.get(stops.size() - 1).getStation();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("  %-10s ", name));
        for (int i = 0; i < stops.size(); i++) {
            ScheduledStop stop = stops.get(i);
            if (i > 0) sb.append(" -> ");
            sb.append(stop.getStation().getName());
            if (stop.getDeparture() != null && stop.getArrival() != null) {
                sb.append(String.format("(%s/%s)", stop.getArrival(), stop.getDeparture()));
            } else if (stop.getDeparture() != null) {
                sb.append(String.format("(dep %s)", stop.getDeparture()));
            } else if (stop.getArrival() != null) {
                sb.append(String.format("(arr %s)", stop.getArrival()));
            }
        }
        return sb.toString();
    }
}

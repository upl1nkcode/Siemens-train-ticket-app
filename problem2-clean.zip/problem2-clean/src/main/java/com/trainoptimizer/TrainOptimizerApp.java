package com.trainoptimizer;

import com.trainoptimizer.model.*;
import com.trainoptimizer.algorithm.TimeExpandedDijkstra;
import com.trainoptimizer.service.NetworkBuilder;

import java.time.LocalTime;
import java.time.Duration;
import java.util.List;
import java.util.Optional;


public class TrainOptimizerApp {

    public static void main(String[] args) {
        System.out.println("=======================================================");
        System.out.println("   OPTIMAL JOURNEY PLANNER — Time-Expanded Dijkstra");
        System.out.println("=======================================================\n");

        
        RailwayNetwork network = NetworkBuilder.buildRomanianNetwork();

        System.out.println("Network loaded: " + network.getStations().size() + " stations, "
                + network.getServices().size() + " train services\n");

        
        System.out.println("--- Available Train Services ---");
        for (TrainService service : network.getServices()) {
            System.out.println(service);
        }
        System.out.println();

        TimeExpandedDijkstra planner = new TimeExpandedDijkstra(network);

        
        runQuery(planner, "Bucharest", "Brasov", LocalTime.of(7, 0));

        
        runQuery(planner, "Bucharest", "Cluj-Napoca", LocalTime.of(6, 0));

        
        runQuery(planner, "Timisoara", "Iasi", LocalTime.of(8, 0));

        
        runQuery(planner, "Bucharest", "Brasov", LocalTime.of(23, 0));

        
        runQuery(planner, "Bucharest", "Bucharest", LocalTime.of(10, 0));

        
        runQuery(planner, "Bucharest", "Iasi", LocalTime.of(6, 0));
    }

    private static void runQuery(TimeExpandedDijkstra planner,
                                  String from, String to, LocalTime departAfter) {
        System.out.println("------------------------------------------------------");
        System.out.printf("QUERY: %s -> %s, departing after %s%n", from, to, departAfter);
        System.out.println("------------------------------------------------------");

        try {
            Optional<Journey> result = planner.findOptimalJourney(from, to, departAfter);

            if (result.isPresent()) {
                Journey journey = result.get();
                System.out.println(journey.prettyPrint());
            } else {
                System.out.println("  [NOT FOUND] No journey found.\n");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("  [ERROR] " + e.getMessage() + "\n");
        }
    }
}

package com.trainoptimizer.algorithm;

import com.trainoptimizer.model.*;

import java.time.Duration;
import java.time.LocalTime;
import java.util.*;


public class TimeExpandedDijkstra {

    private static final int MIN_TRANSFER_MINUTES = 5; 

    private final RailwayNetwork network;

    public TimeExpandedDijkstra(RailwayNetwork network) {
        this.network = Objects.requireNonNull(network);
    }

    
    public Optional<Journey> findOptimalJourney(String originName, String destinationName,
                                                 LocalTime departAfter) {
        Station origin = network.findStation(originName)
                .orElseThrow(() -> new IllegalArgumentException("Unknown station: " + originName));
        Station destination = network.findStation(destinationName)
                .orElseThrow(() -> new IllegalArgumentException("Unknown station: " + destinationName));

        if (origin.equals(destination)) {
            throw new IllegalArgumentException("Origin and destination are the same station.");
        }

        
        List<Event> events = buildEvents();
        Map<Event, List<Edge>> graph = buildGraph(events);

        
        
        Event source = new Event("__SOURCE__", origin, departAfter, EventType.VIRTUAL);

        graph.put(source, new ArrayList<>());
        for (Event event : events) {
            if (event.station.equals(origin)
                    && event.type == EventType.DEPARTURE
                    && !event.time.isBefore(departAfter)) {
                long waitMinutes = minutesBetween(departAfter, event.time);
                graph.get(source).add(new Edge(source, event, waitMinutes));
            }
        }

        
        Map<Event, Long> dist = new HashMap<>();
        Map<Event, Event> prev = new HashMap<>();
        PriorityQueue<long[]> pq = new PriorityQueue<>(Comparator.comparingLong(a -> a[1]));

        int sourceIdx = events.size(); 
        List<Event> allEvents = new ArrayList<>(events);
        allEvents.add(source);

        Map<Event, Integer> eventIndex = new HashMap<>();
        for (int i = 0; i < allEvents.size(); i++) {
            eventIndex.put(allEvents.get(i), i);
        }

        dist.put(source, 0L);
        pq.add(new long[]{sourceIdx, 0});

        while (!pq.isEmpty()) {
            long[] current = pq.poll();
            Event u = allEvents.get((int) current[0]);
            long d = current[1];

            if (dist.containsKey(u) && d > dist.get(u)) continue;

            
            if (u.station.equals(destination) && u.type == EventType.ARRIVAL) {
                return Optional.of(reconstructJourney(u, prev, departAfter));
            }

            for (Edge edge : graph.getOrDefault(u, Collections.emptyList())) {
                long newDist = d + edge.weight;
                if (!dist.containsKey(edge.to) || newDist < dist.get(edge.to)) {
                    dist.put(edge.to, newDist);
                    prev.put(edge.to, u);
                    Integer idx = eventIndex.get(edge.to);
                    if (idx != null) {
                        pq.add(new long[]{idx, newDist});
                    }
                }
            }
        }

        return Optional.empty(); 
    }

    

    private List<Event> buildEvents() {
        List<Event> events = new ArrayList<>();

        for (TrainService service : network.getServices()) {
            for (ScheduledStop stop : service.getStops()) {
                if (stop.getDeparture() != null) {
                    events.add(new Event(service.getName(), stop.getStation(),
                            stop.getDeparture(), EventType.DEPARTURE));
                }
                if (stop.getArrival() != null) {
                    events.add(new Event(service.getName(), stop.getStation(),
                            stop.getArrival(), EventType.ARRIVAL));
                }
            }
        }

        return events;
    }

    private Map<Event, List<Edge>> buildGraph(List<Event> events) {
        Map<Event, List<Edge>> graph = new HashMap<>();
        for (Event e : events) {
            graph.put(e, new ArrayList<>());
        }

        
        for (TrainService service : network.getServices()) {
            List<ScheduledStop> stops = service.getStops();
            for (int i = 0; i < stops.size() - 1; i++) {
                ScheduledStop from = stops.get(i);
                ScheduledStop to = stops.get(i + 1);

                Event depEvent = findEvent(events, service.getName(),
                        from.getStation(), from.getDeparture(), EventType.DEPARTURE);
                Event arrEvent = findEvent(events, service.getName(),
                        to.getStation(), to.getArrival(), EventType.ARRIVAL);

                if (depEvent != null && arrEvent != null) {
                    long travelMinutes = minutesBetween(from.getDeparture(), to.getArrival());
                    graph.get(depEvent).add(new Edge(depEvent, arrEvent, travelMinutes));
                }
            }
        }

        
        
        Map<Station, List<Event>> arrivalsByStation = new HashMap<>();
        Map<Station, List<Event>> departuresByStation = new HashMap<>();

        for (Event e : events) {
            if (e.type == EventType.ARRIVAL) {
                arrivalsByStation.computeIfAbsent(e.station, k -> new ArrayList<>()).add(e);
            } else if (e.type == EventType.DEPARTURE) {
                departuresByStation.computeIfAbsent(e.station, k -> new ArrayList<>()).add(e);
            }
        }

        for (Station station : network.getStations()) {
            List<Event> arrivals = arrivalsByStation.getOrDefault(station, Collections.emptyList());
            List<Event> departures = departuresByStation.getOrDefault(station, Collections.emptyList());

            for (Event arrival : arrivals) {
                for (Event departure : departures) {
                    long waitMinutes = minutesBetween(arrival.time, departure.time);

                    
                    if (arrival.serviceName.equals(departure.serviceName)) {
                        if (waitMinutes >= 0 && waitMinutes <= 30) { 
                            graph.get(arrival).add(new Edge(arrival, departure, waitMinutes));
                        }
                    } else {
                        
                        if (waitMinutes >= MIN_TRANSFER_MINUTES) {
                            graph.get(arrival).add(new Edge(arrival, departure, waitMinutes));
                        }
                    }
                }
            }
        }

        return graph;
    }

    private Event findEvent(List<Event> events, String serviceName, Station station,
                            LocalTime time, EventType type) {
        for (Event e : events) {
            if (e.serviceName.equals(serviceName) && e.station.equals(station)
                    && e.time.equals(time) && e.type == type) {
                return e;
            }
        }
        return null;
    }

    

    private Journey reconstructJourney(Event destination, Map<Event, Event> prev,
                                       LocalTime departAfter) {
        
        List<Event> path = new ArrayList<>();
        Event current = destination;
        while (current != null && !current.serviceName.equals("__SOURCE__")) {
            path.add(current);
            current = prev.get(current);
        }
        Collections.reverse(path);

        
        List<Journey.Leg> legs = new ArrayList<>();
        int i = 0;
        while (i < path.size()) {
            Event depEvent = path.get(i);
            if (depEvent.type != EventType.DEPARTURE) {
                i++;
                continue;
            }

            
            String serviceName = depEvent.serviceName;
            Station legFrom = depEvent.station;
            LocalTime legDepart = depEvent.time;
            Event lastArrival = null;

            int j = i + 1;
            while (j < path.size()) {
                Event next = path.get(j);
                if (next.type == EventType.ARRIVAL && next.serviceName.equals(serviceName)) {
                    lastArrival = next;
                    j++;
                    
                    if (j < path.size() && path.get(j).type == EventType.DEPARTURE
                            && path.get(j).serviceName.equals(serviceName)) {
                        j++;
                        continue;
                    }
                    break;
                } else {
                    break;
                }
            }

            if (lastArrival != null) {
                legs.add(new Journey.Leg(serviceName, legFrom, lastArrival.station,
                        legDepart, lastArrival.time));
            }

            i = j;
        }

        return new Journey(legs);
    }

    

    private static long minutesBetween(LocalTime from, LocalTime to) {
        long minutes = Duration.between(from, to).toMinutes();
        if (minutes < 0) minutes += 24 * 60;
        return minutes;
    }

    private enum EventType {
        DEPARTURE, ARRIVAL, VIRTUAL
    }

    
    private static class Event {
        final String serviceName;
        final Station station;
        final LocalTime time;
        final EventType type;

        Event(String serviceName, Station station, LocalTime time, EventType type) {
            this.serviceName = serviceName;
            this.station = station;
            this.time = time;
            this.type = type;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Event)) return false;
            Event e = (Event) o;
            return serviceName.equals(e.serviceName) && station.equals(e.station)
                    && time.equals(e.time) && type == e.type;
        }

        @Override
        public int hashCode() {
            return Objects.hash(serviceName, station, time, type);
        }

        @Override
        public String toString() {
            return String.format("[%s] %s @ %s (%s)", serviceName, station, time, type);
        }
    }

    
    private static class Edge {
        final Event from;
        final Event to;
        final long weight; 

        Edge(Event from, Event to, long weight) {
            this.from = from;
            this.to = to;
            this.weight = weight;
        }
    }
}

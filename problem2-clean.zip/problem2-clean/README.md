# Problema 2 — Planificator Optimal de Călătorie

## Problema

Găsește cea mai bună călătorie cu trenul între două stații dintr-o rețea feroviară — nu orice rută, ci cea care te aduce la destinație cât mai devreme posibil, ținând cont de orele de plecare, duratele de călătorie și timpii de așteptare la conexiuni.

Asta e semnificativ mai greu decât finderul de rute din Problema 1. BFS spune *că* există o legătură, nu poate spune că trenul direct care pleacă peste 3 ore e mai bun decât trenul mai rapid care a plecat acum 10 minute. 

---

## De Ce Contează

Exact această clasă de problemă o rezolvă Siemens Mobility în productuin, luand in calcul sursele din care m-am interesat. Software-ul din spatele panourilor de afișaj, sistemelor de informare a pasagerilor rulează pe variante ale acestui algoritm. 

Dincolo de căile ferate, aceeași formulare se aplică conexiunilor aeriene, rutării logistice și rețelelor de autobuze. Ori de câte ori exista un graf în care costul unei muchii depinde de *momentul* în care este parcursa, are loc această problemă.

---

## Abordarea/Approach

Ideea cheie este să nu mai interpretam stațiile ca noduri, ci în termeni de **evenimente** — un tren specific, într-o stație specifică, la un moment specific în timp.

Fiecare oprire programată devine două evenimente: o plecare și o sosire. Muchiile le conectează în trei moduri: muchiile de călătorie mută pasagerul de la o plecare la următoarea sosire pe același tren, muchiile de transfer permit schimbarea trenului într-o stație (cu un minim de 5 minute de așteptare impus), iar muchiile de continuare pe același tren gestionează opririle intermediare unde pur și simplu rămâi la bord.

Odată construit astfel graful, găsirea călătoriei optime este doar Dijkstra — minimizezi timpul total scurs de la origine la destinație. Un nod sursă virtual se conectează la toate plecările valide din stația de origine după ora solicitată, astfel încât algoritmul elimina dilema "când pot pleca?".

---

## Detalii de Implementare

- **`TimeExpandedDijkstra.java`** — construiește graful de evenimente din orar și rulează căutarea. Graful este construit per interogare; ușor de cache-uit într-un context de producție.
- **`Journey.java`** — tipul rezultat, conținând o listă ordonată de segmente. Returnează `Optional<Journey>` —  faptul ca nu se gaseste nici o calatorie este un rezultat normal, nu o eroare.
- **`NetworkBuilder.java`** — 8 stații românești și 11 servicii de tren cu orare CFR realiste, folosite ca rețea demo.

---

## Cum se Rulează

```bash
# Cu Maven
mvn exec:java

# Fără Maven
javac -d out $(find src/main -name "*.java")
java -cp out com.trainoptimizer.TrainOptimizerApp
java -cp "target\classes" com.trainoptimizer.TrainOptimizerApp 
```
